<?php

namespace SwagController;

use Shopware\Components\Plugin;

class SwagController extends Plugin
{

}